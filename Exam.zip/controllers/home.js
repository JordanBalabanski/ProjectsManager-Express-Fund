

module.exports = {
  index: async (req, res) => {
    res.render('home/index');
  }
}